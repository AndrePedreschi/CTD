package Prova1;

public interface IDao <T>{
    public T salvar(T t);
}
