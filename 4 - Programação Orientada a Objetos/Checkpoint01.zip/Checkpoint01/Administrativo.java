package Checkpoint01;

public class Administrativo extends Funcionarios {

    public Administrativo(String nome, Double salario) {
        super();

    }

}
