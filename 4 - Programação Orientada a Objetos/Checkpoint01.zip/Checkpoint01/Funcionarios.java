package Checkpoint01;

public class Funcionarios {
    private String nome;
    private Double salario;

    //construtor
    public Funcionarios() {
    }



}


