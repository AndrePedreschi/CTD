package Checkpoint01;


public class Coordenadores extends Funcionarios{

    private String modalidade;


    public Coordenadores(String nome, Double salario, String modalidade) {
        super();

        this.modalidade = modalidade;

    }


}
